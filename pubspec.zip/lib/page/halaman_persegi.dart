import 'package:flutter/material.dart';

class HalamanPersegi extends StatelessWidget {
  const HalamanPersegi({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}